class Level1Scene extends Phaser.Scene {
  constructor() {
    super('Level1Scene');
  }

  preload() {
    // Joueur
    this.load.image('player_idle', 'assets/player1.png');
    this.load.image('player_run', 'assets/player2.png');
    this.load.image('player_jump', 'assets/player3.png');

    // Ennemi
    this.load.image('enemy', 'assets/enemy.png');

    // Fond
    this.load.image('bgLevel1', 'assets/bg_level1.png');

    // Sol
    this.load.image('floorTile', 'assets/floorTile.png');
  }

  create() {
    const W = this.scale.width;
    const H = this.scale.height;

    // === Paramètres niveau ===
    const LEVEL_WIDTH = W * 5;       // longueur totale du niveau
    const GROUND_HEIGHT = 70;        // épaisseur du sol

    // === Monde & caméra ===
    this.physics.world.setBounds(0, 0, LEVEL_WIDTH, H + 400);
    this.cameras.main.setBounds(0, 0, LEVEL_WIDTH, H);

    // === Background fixe (collé à la caméra) ===
    const bg = this.add.image(W / 2, H / 2, 'bgLevel1');
    bg.setScrollFactor(0);
    const scaleX = W / bg.width;
    const scaleY = H / bg.height;
    const scale = Math.max(scaleX, scaleY);
    bg.setScale(scale);

    // === Plateformes/statique ===
    this.platforms = this.physics.add.staticGroup();

    // Helper sol "Mario"
    const makeGround = (startX, endX) => {
      const width = endX - startX;
      const centerX = startX + width / 2;

      const floor = this.add.image(centerX, H, 'floorTile')
        .setOrigin(0.5, 1);
      floor.displayWidth = width;
      floor.displayHeight = GROUND_HEIGHT;

      const collider = this.add.rectangle(
        centerX,
        H - GROUND_HEIGHT / 2,
        width,
        GROUND_HEIGHT
      );
      this.physics.add.existing(collider, true);
      this.platforms.add(collider);
    };

    // Helper plateforme en hauteur
    const graphics = this.add.graphics();
    graphics.fillStyle(0xf4a623, 1);

    const makePlatform = (x, y, width, height) => {
      graphics.fillRect(x - width / 2, y - height / 2, width, height);
      const rect = this.add.rectangle(x, y, width, height);
      this.physics.add.existing(rect, true);
      this.platforms.add(rect);
    };

    // === Layout du niveau (sol) ===
    // zone départ
    makeGround(0, W * 1.4);
    // petit trou
    makeGround(W * 1.6, W * 2.6);
    // plus gros trou
    makeGround(W * 2.9, W * 3.9);
    // fin de niveau
    makeGround(W * 4.2, LEVEL_WIDTH);

    // === Plateformes type "blocs" ===
    // petit escalier après départ
    makePlatform(W * 0.9, H - GROUND_HEIGHT - 60, 80, 25);
    makePlatform(W * 1.0, H - GROUND_HEIGHT - 110, 80, 25);

    // trois blocs au-dessus du 1er trou
    makePlatform(W * 1.8, H - GROUND_HEIGHT - 80, 80, 25);
    makePlatform(W * 2.0, H - GROUND_HEIGHT - 120, 80, 25);
    makePlatform(W * 2.2, H - GROUND_HEIGHT - 80, 80, 25);

    // plateformes avant le grand trou
    makePlatform(W * 2.9, H - GROUND_HEIGHT - 70, 100, 25);
    makePlatform(W * 3.1, H - GROUND_HEIGHT - 130, 100, 25);
    makePlatform(W * 3.3, H - GROUND_HEIGHT - 70, 100, 25);

    // plateforme haute vers la fin
    makePlatform(W * 4.5, H - GROUND_HEIGHT - 120, 130, 25);

    // === Joueur ===
    this.player = this.physics.add.sprite(80, H - GROUND_HEIGHT - 120, 'player_idle');
    this.player.setScale(0.5);
    this.player.setBounce(0.1);
    this.player.setCollideWorldBounds(false);        // pour pouvoir tomber dans le vide
    this.player.setDragX(3000);
    this.player.setMaxVelocity(800, 2000);
    this.physics.add.collider(this.player, this.platforms);
    this.player.body.setFriction(2, 0);

    // === Ennemis ===
    this.enemies = this.physics.add.group();

    // Chaque ennemi a une zone de patrouille [left, right]
    this.spawnEnemy(W * 0.8, H - GROUND_HEIGHT - 80,  W * 0.6, W * 1.0);
    this.spawnEnemy(W * 1.9, H - GROUND_HEIGHT - 80,  W * 1.7, W * 2.3);
    this.spawnEnemy(W * 3.2, H - GROUND_HEIGHT - 80,  W * 3.0, W * 3.6);
    this.spawnEnemy(W * 4.4, H - GROUND_HEIGHT - 80,  W * 4.2, W * 4.8);

    this.physics.add.collider(this.enemies, this.platforms);

    // Joueur touche ennemi → mort
    this.physics.add.overlap(
      this.player,
      this.enemies,
      this.handlePlayerEnemyCollision,
      null,
      this
    );

    // === Caméra qui suit le joueur ===
    this.cameras.main.startFollow(this.player, true, 0.1, 0.1);

    // === Contrôles clavier ===
    this.cursors = this.input.keyboard.createCursorKeys();

    // UI
    this.helpText = this.add.text(16, 16,
      '← → pour bouger | ↑ pour sauter',
      { fontSize: '18px', fill: '#ffffff' }
    );
    this.helpText.setScrollFactor(0);
  }

  update() {
    if (!this.cursors) return;

    const accel = 1200;
    const maxSpeed = 600;
    const H = this.scale.height;

    // === Déplacement horizontal ===
    if (this.cursors.left.isDown) {
      this.player.setAccelerationX(-accel);
      this.player.flipX = true;
    } else if (this.cursors.right.isDown) {
      this.player.setAccelerationX(accel);
      this.player.flipX = false;
    } else {
      this.player.setAccelerationX(0);
    }

    // Clamp vitesse horizontale
    const vx = this.player.body.velocity.x;
    if (Math.abs(vx) > maxSpeed) {
      this.player.setVelocityX(Phaser.Math.Clamp(vx, -maxSpeed, maxSpeed));
    }
    if (Math.abs(vx) < 5) {
      this.player.setVelocityX(0);
    }

    // Sol / air
    const onGround =
      this.player.body.blocked.down || this.player.body.touching.down;

    // Saut
    if (Phaser.Input.Keyboard.JustDown(this.cursors.up) && onGround) {
      this.player.setVelocityY(-1500);
    }

    // Sprite selon l'état
    const moving = Math.abs(this.player.body.velocity.x) > 10;
    const jumping = !onGround;

    if (jumping) {
      if (this.player.texture.key !== 'player_jump') {
        this.player.setTexture('player_jump');
      }
    } else if (moving) {
      if (this.player.texture.key !== 'player_run') {
        this.player.setTexture('player_run');
      }
    } else {
      if (this.player.texture.key !== 'player_idle') {
        this.player.setTexture('player_idle');
      }
    }

    // Mort si chute dans un trou
    if (this.player.y > H + 200) {
      this.scene.restart();
    }

    // === Patrouille des ennemis (zone [patrolLeft, patrolRight]) ===
    this.enemies.children.iterate(enemy => {
      if (!enemy || !enemy.body) return;

      if (enemy.x <= enemy.patrolLeft) {
        enemy.direction = 1;
      } else if (enemy.x >= enemy.patrolRight) {
        enemy.direction = -1;
      }

      enemy.setVelocityX(enemy.speed * enemy.direction);
      enemy.flipX = enemy.direction < 0;
    });
  }

  /**
   * Crée un ennemi avec une zone de patrouille donnée
   * @param {number} x position de départ
   * @param {number} y position de départ
   * @param {number} patrolLeft limite gauche
   * @param {number} patrolRight limite droite
   */
  spawnEnemy(x, y, patrolLeft, patrolRight) {
    const enemy = this.enemies.create(x, y, 'enemy');
    enemy.setScale(0.5);
    enemy.setCollideWorldBounds(false);  // il peut tomber dans les trous
    enemy.body.setImmovable(false);

    enemy.patrolLeft = patrolLeft;
    enemy.patrolRight = patrolRight;
    enemy.direction = 1;
    enemy.speed = 70;

    enemy.setVelocityX(enemy.speed * enemy.direction);
  }

  handlePlayerEnemyCollision(player, enemy) {
    this.scene.restart();
  }
}
